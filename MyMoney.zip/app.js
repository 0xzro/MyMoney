// app.js — MyMoney Complete Application Logic
// v1.0.1 | by AKASH B

// ======= STATE =======
let state = {
  currentPage: 'dashboard',
  txType: 'expense',
  editTxType: 'expense',
  editTxId: null,
  transactions: [],
  wallets: [],
  categories: [],
  cryptoEntries: [],
  budgets: [],
  txFilter: 'all',
  walletColor: '#00FF87',
  charts: {},
  loading: false,
};

// ======= RAZORPAY CONFIG =======
const RAZORPAY_KEY = 'YOUR_RAZORPAY_KEY_ID'; // Replace with your key

// ======= PROMO CODES =======
const PROMO_CODES = {
  'AKASH10': { discount: 10, type: 'percent', plan: 'pro' },
  'LAUNCH50': { discount: 50, type: 'percent', plan: 'both' },
  'FREE30':  { discount: 30, type: 'days', plan: 'pro' },
};

// ======= UTILS =======
const fmt = (n) => '₹' + Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
const fmtDate = (d) => new Date(d).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
const today = () => new Date().toISOString().split('T')[0];
const monthName = (d = new Date()) => d.toLocaleString('en-IN', { month: 'long', year: 'numeric' });

function showToast(msg, type = 'success') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `toast show ${type}`;
  setTimeout(() => t.className = 'toast', 2500);
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

function openModal(id) {
  document.getElementById(id).classList.add('open');
}

// ======= BOOT =======
window.onFirebaseReady = async function(user) {
  // Set user info in sidebar
  const profile = window._userProfile || {};
  document.getElementById('userName').textContent = profile.name || user.displayName || 'User';
  document.getElementById('userEmail').textContent = user.email;
  document.getElementById('userAvatar').textContent = (profile.name || user.displayName || 'U')[0].toUpperCase();

  // Plan badge
  const plan = profile.plan || 'free';
  const badge = document.getElementById('planBadge');
  badge.textContent = plan === 'lifetime' ? '⭐ LIFETIME' : plan === 'pro' ? '⚡ PRO' : 'FREE PLAN';
  badge.className = plan === 'free' ? 'badge badge-green' : 'badge badge-yellow';

  // Hide upgrade btn for lifetime
  if (plan === 'lifetime') document.getElementById('upgradeBtn').style.display = 'none';
  // Hide upgrade banner for pro/lifetime
  if (plan !== 'free') document.getElementById('upgradeBanner').style.display = 'none';

  // Lock AI for free
  if (plan === 'free') document.getElementById('assistantLock').style.display = 'flex';

  // Referral code
  const refInput = document.getElementById('refCodeDisplay');
  if (refInput) refInput.value = profile.referralCode || 'MMXXXXXX';

  // Settings prefill
  document.getElementById('settingsName').value = profile.name || user.displayName || '';
  document.getElementById('settingsEmail').value = user.email;
  document.getElementById('subscriptionInfo').textContent =
    plan === 'free' ? 'Free Plan — Limited features'
    : plan === 'pro' ? '⚡ Pro Plan — Active'
    : '⭐ Lifetime Plan — Unlimited forever';

  // Init month selector
  populateMonthSelector();

  // Set today's date defaults
  document.getElementById('txDate').value = today();
  document.getElementById('cryptoDate').value = today();
  const ef = document.getElementById('exportFrom');
  const et = document.getElementById('exportTo');
  if (ef) { const d = new Date(); d.setDate(1); ef.value = d.toISOString().split('T')[0]; }
  if (et) et.value = today();

  // Load all data
  await Promise.all([loadWallets(), loadCategories(), loadTransactions(), loadCrypto(), loadBudgets()]);

  // Render dashboard
  renderDashboard();
};

// ======= NAVIGATION =======
function navigate(page) {
  state.currentPage = page;

  // Hide all pages
  document.querySelectorAll('.page-content').forEach(p => p.classList.remove('active'));
  const pg = document.getElementById(`page-${page}`);
  if (pg) { pg.classList.add('active'); pg.classList.remove('animate-in'); void pg.offsetWidth; pg.classList.add('animate-in'); }

  // Sidebar nav highlight
  document.querySelectorAll('.nav-item[data-page]').forEach(i => {
    i.classList.toggle('active', i.dataset.page === page);
  });
  // Mobile nav highlight
  document.querySelectorAll('.mobile-nav-item[data-page]').forEach(i => {
    i.classList.toggle('active', i.dataset.page === page);
  });

  // Page title
  const titles = {
    dashboard:'Dashboard', transactions:'Transactions', wallets:'Wallets',
    crypto:'Crypto & Airdrops', analytics:'Analytics', budget:'Budget',
    assistant:'AI Assistant', categories:'Categories', export:'Export Data',
    referral:'Refer & Earn', settings:'Settings'
  };
  document.getElementById('pageTitle').textContent = titles[page] || page;

  // Close mobile sidebar
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.remove('show');

  // Page-specific renders
  if (page === 'transactions') renderTransactions();
  if (page === 'wallets') renderWallets();
  if (page === 'crypto') renderCrypto();
  if (page === 'analytics') renderAnalytics();
  if (page === 'budget') renderBudget();
  if (page === 'categories') renderCategories();
  if (page === 'export') populateExportWalletFilter();
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('sidebarOverlay').classList.toggle('show');
}

// ======= DATA LOADERS =======
async function loadTransactions() {
  if (!window._user) return;
  try {
    const q = window._query(
      window._collection(window._db, 'users', window._user.uid, 'transactions'),
      window._orderBy('date', 'desc')
    );
    const snap = await window._getDocs(q);
    state.transactions = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (e) {
    // Offline fallback
    const local = localStorage.getItem('mm_transactions');
    if (local) state.transactions = JSON.parse(local);
  }
}

async function loadWallets() {
  if (!window._user) return;
  try {
    const snap = await window._getDocs(window._collection(window._db, 'users', window._user.uid, 'wallets'));
    state.wallets = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (e) {
    const local = localStorage.getItem('mm_wallets');
    if (local) state.wallets = JSON.parse(local);
  }
}

async function loadCategories() {
  if (!window._user) return;
  try {
    const snap = await window._getDocs(window._collection(window._db, 'users', window._user.uid, 'categories'));
    state.categories = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (e) {
    const local = localStorage.getItem('mm_categories');
    if (local) state.categories = JSON.parse(local);
  }
}

async function loadCrypto() {
  if (!window._user) return;
  try {
    const snap = await window._getDocs(window._collection(window._db, 'users', window._user.uid, 'crypto'));
    state.cryptoEntries = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (e) {
    const local = localStorage.getItem('mm_crypto');
    if (local) state.cryptoEntries = JSON.parse(local);
  }
}

async function loadBudgets() {
  if (!window._user) return;
  try {
    const snap = await window._getDocs(window._collection(window._db, 'users', window._user.uid, 'budgets'));
    state.budgets = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (e) {
    const local = localStorage.getItem('mm_budgets');
    if (local) state.budgets = JSON.parse(local);
  }
}

// ======= DASHBOARD =======
function renderDashboard() {
  const now = new Date();
  const todayStr = today();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const todayTx = state.transactions.filter(t => t.date === todayStr);
  const monthTx = state.transactions.filter(t => {
    const d = new Date(t.date);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  });

  const todaySpend = todayTx.filter(t => t.type === 'expense').reduce((a, t) => a + t.amount, 0);
  const monthSpend = monthTx.filter(t => t.type === 'expense').reduce((a, t) => a + t.amount, 0);
  const monthIncome = monthTx.filter(t => t.type === 'income').reduce((a, t) => a + t.amount, 0);
  const totalBalance = state.wallets.reduce((a, w) => a + (w.balance || 0), 0);
  const netSavings = monthIncome - monthSpend;

  document.getElementById('totalBalance').textContent = fmt(totalBalance);
  document.getElementById('todaySpend').textContent = fmt(todaySpend);
  document.getElementById('todayCount').textContent = `${todayTx.length} transaction${todayTx.length !== 1 ? 's' : ''}`;
  document.getElementById('monthSpend').textContent = fmt(monthSpend);
  document.getElementById('monthName').textContent = monthName();
  document.getElementById('monthIncome').textContent = fmt(monthIncome);
  const ns = document.getElementById('netSavings');
  ns.textContent = fmt(Math.abs(netSavings));
  ns.className = netSavings >= 0 ? 'green' : 'red';

  // Recent transactions (last 8)
  const recentList = document.getElementById('recentTxList');
  const recent = state.transactions.slice(0, 8);
  if (recent.length === 0) {
    recentList.innerHTML = `<div class="empty-state"><div class="empty-icon">💸</div><p>No transactions yet.<br>Add your first one!</p></div>`;
  } else {
    recentList.innerHTML = recent.map(t => txHTML(t)).join('');
  }

  // Top categories
  const catSpend = {};
  monthTx.filter(t => t.type === 'expense').forEach(t => {
    catSpend[t.category] = (catSpend[t.category] || 0) + t.amount;
  });
  const sortedCats = Object.entries(catSpend).sort((a,b) => b[1]-a[1]).slice(0, 4);
  const topCatList = document.getElementById('topCategoriesList');
  if (sortedCats.length === 0) {
    topCatList.innerHTML = `<div style="color:var(--muted);font-size:13px;">No expense data yet</div>`;
  } else {
    const maxVal = sortedCats[0][1];
    topCatList.innerHTML = sortedCats.map(([catId, val]) => {
      const cat = state.categories.find(c => c.id === catId) || { name: catId, icon: '💰' };
      const pct = Math.round((val / maxVal) * 100);
      return `
        <div style="margin-bottom:12px;">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
            <span style="font-size:13px;">${cat.icon || '💰'} ${cat.name}</span>
            <span class="mono" style="font-size:12px;">${fmt(val)}</span>
          </div>
          <div class="progress-bar"><div class="progress-fill" style="width:${pct}%;background:${cat.color || 'var(--green)'}"></div></div>
        </div>
      `;
    }).join('');
  }

  // Wallet summary
  const dashWallets = document.getElementById('dashWalletList');
  if (state.wallets.length === 0) {
    dashWallets.innerHTML = `<div style="color:var(--muted);font-size:13px;">No wallets</div>`;
  } else {
    dashWallets.innerHTML = state.wallets.map(w => `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border);">
        <div style="display:flex;align-items:center;gap:8px;">
          <div style="width:8px;height:8px;border-radius:50%;background:${w.color || '#00FF87'};"></div>
          <span style="font-size:13px;">${w.name}</span>
        </div>
        <span class="mono" style="font-size:13px;font-weight:700;">${fmt(w.balance)}</span>
      </div>
    `).join('');
  }

  // Mini dashboard chart
  renderDashChart(monthTx);
}

function renderDashChart(monthTx) {
  const canvas = document.getElementById('dashChart');
  if (!canvas) return;

  if (state.charts.dash) state.charts.dash.destroy();

  // Group by week
  const weeks = ['Week 1','Week 2','Week 3','Week 4'];
  const incomeByWeek = [0,0,0,0];
  const expenseByWeek = [0,0,0,0];

  monthTx.forEach(t => {
    const day = new Date(t.date).getDate();
    const wk = Math.min(Math.floor((day-1)/7), 3);
    if (t.type === 'income') incomeByWeek[wk] += t.amount;
    else expenseByWeek[wk] += t.amount;
  });

  state.charts.dash = new Chart(canvas, {
    type: 'bar',
    data: {
      labels: weeks,
      datasets: [
        { label:'Income', data: incomeByWeek, backgroundColor: 'rgba(0,255,135,0.6)', borderRadius: 6 },
        { label:'Expense', data: expenseByWeek, backgroundColor: 'rgba(255,77,77,0.6)', borderRadius: 6 }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { labels: { color: '#888', font: { family:'Space Mono' } } } },
      scales: {
        x: { grid: { color: '#1a1a1a' }, ticks: { color: '#666' } },
        y: { grid: { color: '#1a1a1a' }, ticks: { color: '#666', callback: v => '₹' + v.toLocaleString('en-IN') } }
      }
    }
  });
}

// ======= TRANSACTION HTML =======
function txHTML(t) {
  const cat = state.categories.find(c => c.id === t.category) || { icon: '💰', name: t.category, color: '#666' };
  const wallet = state.wallets.find(w => w.id === t.walletId) || { name: 'Wallet' };
  return `
    <div class="tx-item" onclick="openEditTransaction('${t.id}')">
      <div class="tx-icon" style="background:${cat.color}22;">${cat.icon || '💰'}</div>
      <div class="tx-info">
        <div class="tx-name">${t.notes || cat.name}</div>
        <div class="tx-meta">${cat.name} · ${wallet.name} · ${fmtDate(t.date)}</div>
      </div>
      <div class="tx-amount" style="color:${t.type === 'income' ? 'var(--green)' : 'var(--red)'}">
        ${t.type === 'income' ? '+' : '-'}${fmt(t.amount)}
      </div>
    </div>
  `;
}

// ======= TRANSACTIONS PAGE =======
let currentTxFilter = 'all';
function setTxFilter(filter, btn) {
  currentTxFilter = filter;
  document.querySelectorAll('#txFilterPills .filter-pill').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderTransactions();
}

function renderTransactions() {
  const search = (document.getElementById('txSearch')?.value || '').toLowerCase();
  const walletFilter = document.getElementById('txWalletFilter')?.value || 'all';
  const now = new Date();

  let filtered = state.transactions.filter(t => {
    const d = new Date(t.date);
    const cat = state.categories.find(c => c.id === t.category);
    const matchSearch = !search ||
      (t.notes && t.notes.toLowerCase().includes(search)) ||
      (cat && cat.name.toLowerCase().includes(search)) ||
      t.amount.toString().includes(search);
    const matchWallet = walletFilter === 'all' || t.walletId === walletFilter;
    let matchFilter = true;
    if (currentTxFilter === 'today') matchFilter = t.date === today();
    else if (currentTxFilter === 'week') {
      const weekAgo = new Date(); weekAgo.setDate(weekAgo.getDate() - 7);
      matchFilter = d >= weekAgo;
    }
    else if (currentTxFilter === 'month') matchFilter = d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    else if (currentTxFilter === 'income') matchFilter = t.type === 'income';
    else if (currentTxFilter === 'expense') matchFilter = t.type === 'expense';
    return matchSearch && matchWallet && matchFilter;
  });

  const totalIn = filtered.filter(t => t.type === 'income').reduce((a,t) => a+t.amount, 0);
  const totalOut = filtered.filter(t => t.type === 'expense').reduce((a,t) => a+t.amount, 0);
  document.getElementById('txTotalCount').textContent = filtered.length;
  document.getElementById('txTotalIn').textContent = fmt(totalIn);
  document.getElementById('txTotalOut').textContent = fmt(totalOut);

  const list = document.getElementById('txList');
  if (filtered.length === 0) {
    list.innerHTML = `<div class="empty-state"><div class="empty-icon">🔍</div><p>No transactions match.</p></div>`;
    return;
  }
  // Group by date
  const grouped = {};
  filtered.forEach(t => {
    if (!grouped[t.date]) grouped[t.date] = [];
    grouped[t.date].push(t);
  });
  list.innerHTML = Object.entries(grouped)
    .sort(([a],[b]) => b.localeCompare(a))
    .map(([date, txs]) => `
      <div style="margin-bottom:8px;">
        <div style="font-size:12px;font-weight:600;color:var(--muted);padding:8px 0;text-transform:uppercase;letter-spacing:0.5px;">${fmtDate(date)}</div>
        ${txs.map(t => txHTML(t)).join('')}
      </div>
    `).join('');
}

function populateTxWalletFilter() {
  const sel = document.getElementById('txWalletFilter');
  if (!sel) return;
  sel.innerHTML = '<option value="all">All Wallets</option>' + state.wallets.map(w => `<option value="${w.id}">${w.name}</option>`).join('');
}

// ======= ADD TRANSACTION =======
function openAddTransaction(type = 'expense') {
  state.txType = type;
  setTxType(type);
  populateCategorySelect('txCategory', type);
  populateWalletSelect('txWallet');
  document.getElementById('txAmount').value = '';
  document.getElementById('txNotes').value = '';
  document.getElementById('txDate').value = today();
  document.getElementById('txError').style.display = 'none';
  document.getElementById('addTxTitle').textContent = type === 'income' ? '+ Add Income' : '+ Add Expense';
  openModal('addTxModal');
  setTimeout(() => document.getElementById('txAmount').focus(), 100);
}

function setTxType(type) {
  state.txType = type;
  document.getElementById('typeExpense').className = `type-btn expense ${type === 'expense' ? 'active' : ''}`;
  document.getElementById('typeIncome').className = `type-btn income ${type === 'income' ? 'active' : ''}`;
  populateCategorySelect('txCategory', type);
}

function setEditTxType(type) {
  state.editTxType = type;
  document.getElementById('editTypeExpense').className = `type-btn expense ${type === 'expense' ? 'active' : ''}`;
  document.getElementById('editTypeIncome').className = `type-btn income ${type === 'income' ? 'active' : ''}`;
  populateCategorySelect('editTxCategory', type);
}

function populateCategorySelect(selectId, type) {
  const sel = document.getElementById(selectId);
  if (!sel) return;
  const cats = state.categories.filter(c => c.type === type);
  sel.innerHTML = cats.map(c => `<option value="${c.id}">${c.icon || ''} ${c.name}</option>`).join('');
}

function populateWalletSelect(selectId) {
  const sel = document.getElementById(selectId);
  if (!sel) return;
  const plan = window._userProfile?.plan || 'free';
  const available = plan === 'free' ? state.wallets.slice(0, 1) : state.wallets;
  sel.innerHTML = available.map(w => `<option value="${w.id}">${w.name}</option>`).join('');
  if (available.length === 0) sel.innerHTML = '<option value="">No wallets — add one first</option>';
}

async function saveTransaction() {
  const amount = parseFloat(document.getElementById('txAmount').value);
  const category = document.getElementById('txCategory').value;
  const walletId = document.getElementById('txWallet').value;
  const notes = document.getElementById('txNotes').value.trim();
  const date = document.getElementById('txDate').value;
  const errEl = document.getElementById('txError');

  if (!amount || amount <= 0) { errEl.textContent = 'Please enter a valid amount.'; errEl.style.display='block'; return; }
  if (!walletId) { errEl.textContent = 'Please select a wallet.'; errEl.style.display='block'; return; }
  if (!date) { errEl.textContent = 'Please select a date.'; errEl.style.display='block'; return; }
  errEl.style.display = 'none';

  const btn = document.getElementById('saveTxBtn');
  btn.disabled = true; btn.textContent = 'Saving...';

  try {
    const tx = {
      type: state.txType,
      amount,
      category,
      walletId,
      notes,
      date,
      createdAt: window._serverTimestamp ? window._serverTimestamp() : new Date().toISOString(),
    };

    // Save to Firestore
    const ref = await window._addDoc(window._collection(window._db, 'users', window._user.uid, 'transactions'), tx);
    tx.id = ref.id;

    // Update wallet balance
    const wallet = state.wallets.find(w => w.id === walletId);
    if (wallet) {
      const newBal = state.txType === 'income' ? wallet.balance + amount : wallet.balance - amount;
      await window._updateDoc(window._doc(window._db, 'users', window._user.uid, 'wallets', walletId), { balance: newBal });
      wallet.balance = newBal;
    }

    state.transactions.unshift(tx);
    localStorage.setItem('mm_transactions', JSON.stringify(state.transactions));
    closeModal('addTxModal');
    renderDashboard();
    if (state.currentPage === 'transactions') renderTransactions();
    showToast(`${state.txType === 'income' ? '💰' : '💸'} Transaction saved!`);

    // Budget check
    checkBudgetAlert(category, amount);
  } catch (e) {
    errEl.textContent = 'Error saving. Check your connection.';
    errEl.style.display = 'block';
    console.error(e);
  }
  btn.disabled = false; btn.textContent = 'Save Transaction';
}

function checkBudgetAlert(categoryId, amount) {
  const budget = state.budgets.find(b => b.categoryId === categoryId);
  if (!budget) return;
  const now = new Date();
  const spent = state.transactions
    .filter(t => t.category === categoryId && t.type === 'expense' && new Date(t.date).getMonth() === now.getMonth())
    .reduce((a,t) => a+t.amount, 0);
  if (spent >= budget.limit) showToast(`⚠️ Budget exceeded for ${categoryId}!`, 'error');
  else if (spent >= budget.limit * 0.8) showToast(`⚡ 80% of ${categoryId} budget used`, 'error');
}

// ======= EDIT / DELETE TRANSACTION =======
function openEditTransaction(txId) {
  const tx = state.transactions.find(t => t.id === txId);
  if (!tx) return;
  state.editTxId = txId;
  state.editTxType = tx.type;

  document.getElementById('editTypeExpense').className = `type-btn expense ${tx.type === 'expense' ? 'active' : ''}`;
  document.getElementById('editTypeIncome').className = `type-btn income ${tx.type === 'income' ? 'active' : ''}`;
  populateCategorySelect('editTxCategory', tx.type);
  populateWalletSelect('editTxWallet');
  document.getElementById('editTxAmount').value = tx.amount;
  document.getElementById('editTxNotes').value = tx.notes || '';
  document.getElementById('editTxDate').value = tx.date;

  setTimeout(() => {
    document.getElementById('editTxCategory').value = tx.category;
    document.getElementById('editTxWallet').value = tx.walletId;
  }, 50);

  openModal('editTxModal');
}

async function updateTransaction() {
  const tx = state.transactions.find(t => t.id === state.editTxId);
  if (!tx) return;

  const amount = parseFloat(document.getElementById('editTxAmount').value);
  const category = document.getElementById('editTxCategory').value;
  const walletId = document.getElementById('editTxWallet').value;
  const notes = document.getElementById('editTxNotes').value.trim();
  const date = document.getElementById('editTxDate').value;

  if (!amount || amount <= 0) return showToast('Invalid amount', 'error');

  try {
    // Reverse old wallet balance
    const oldWallet = state.wallets.find(w => w.id === tx.walletId);
    if (oldWallet) {
      const reversed = tx.type === 'income' ? oldWallet.balance - tx.amount : oldWallet.balance + tx.amount;
      await window._updateDoc(window._doc(window._db, 'users', window._user.uid, 'wallets', tx.walletId), { balance: reversed });
      oldWallet.balance = reversed;
    }

    // Apply new wallet balance
    const newWallet = state.wallets.find(w => w.id === walletId);
    if (newWallet) {
      const applied = state.editTxType === 'income' ? newWallet.balance + amount : newWallet.balance - amount;
      await window._updateDoc(window._doc(window._db, 'users', window._user.uid, 'wallets', walletId), { balance: applied });
      newWallet.balance = applied;
    }

    const updates = { type: state.editTxType, amount, category, walletId, notes, date };
    await window._updateDoc(window._doc(window._db, 'users', window._user.uid, 'transactions', state.editTxId), updates);

    const idx = state.transactions.findIndex(t => t.id === state.editTxId);
    state.transactions[idx] = { ...tx, ...updates };
    localStorage.setItem('mm_transactions', JSON.stringify(state.transactions));

    closeModal('editTxModal');
    renderDashboard();
    if (state.currentPage === 'transactions') renderTransactions();
    showToast('✏️ Transaction updated!');
  } catch (e) {
    showToast('Error updating transaction', 'error');
    console.error(e);
  }
}

async function deleteTransaction() {
  if (!confirm('Delete this transaction?')) return;
  const tx = state.transactions.find(t => t.id === state.editTxId);
  if (!tx) return;

  try {
    // Reverse wallet balance
    const wallet = state.wallets.find(w => w.id === tx.walletId);
    if (wallet) {
      const reversed = tx.type === 'income' ? wallet.balance - tx.amount : wallet.balance + tx.amount;
      await window._updateDoc(window._doc(window._db, 'users', window._user.uid, 'wallets', tx.walletId), { balance: reversed });
      wallet.balance = reversed;
    }

    await window._deleteDoc(window._doc(window._db, 'users', window._user.uid, 'transactions', state.editTxId));
    state.transactions = state.transactions.filter(t => t.id !== state.editTxId);
    localStorage.setItem('mm_transactions', JSON.stringify(state.transactions));

    closeModal('editTxModal');
    renderDashboard();
    if (state.currentPage === 'transactions') renderTransactions();
    showToast('🗑️ Transaction deleted');
  } catch (e) {
    showToast('Error deleting', 'error');
  }
}

// ======= WALLETS =======
function openAddWallet() {
  const plan = window._userProfile?.plan || 'free';
  if (plan === 'free' && state.wallets.length >= 1) {
    showUpgradeModal();
    showToast('Upgrade to Pro for multiple wallets', 'error');
    return;
  }
  document.getElementById('walletName').value = '';
  document.getElementById('walletBalance').value = '0';
  state.walletColor = '#00FF87';
  openModal('addWalletModal');
}

function setWalletColor(color, el) {
  state.walletColor = color;
  document.querySelectorAll('#addWalletModal [onclick^="setWalletColor"]').forEach(e => e.style.border = 'none');
  el.style.border = '2px solid #fff';
}

async function saveWallet() {
  const name = document.getElementById('walletName').value.trim();
  const type = document.getElementById('walletType').value;
  const balance = parseFloat(document.getElementById('walletBalance').value) || 0;

  if (!name) return showToast('Enter wallet name', 'error');

  try {
    const wallet = { name, type, balance, color: state.walletColor, createdAt: window._serverTimestamp() };
    const ref = await window._addDoc(window._collection(window._db, 'users', window._user.uid, 'wallets'), wallet);
    wallet.id = ref.id;
    state.wallets.push(wallet);
    localStorage.setItem('mm_wallets', JSON.stringify(state.wallets));
    closeModal('addWalletModal');
    renderWallets();
    populateTxWalletFilter();
    renderDashboard();
    showToast('🏦 Wallet added!');
  } catch (e) {
    showToast('Error saving wallet', 'error');
  }
}

function renderWallets() {
  const grid = document.getElementById('walletGrid');
  if (!grid) return;
  if (state.wallets.length === 0) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;"><div class="empty-icon">🏦</div><p>No wallets yet. Add one!</p></div>`;
    return;
  }
  const walletIcons = { bank:'🏦', cash:'💵', crypto:'₿', business:'📈', savings:'🏺' };
  grid.innerHTML = state.wallets.map(w => {
    const txCount = state.transactions.filter(t => t.walletId === w.id).length;
    const income = state.transactions.filter(t => t.walletId === w.id && t.type === 'income').reduce((a,t) => a+t.amount, 0);
    const expense = state.transactions.filter(t => t.walletId === w.id && t.type === 'expense').reduce((a,t) => a+t.amount, 0);
    return `
      <div class="wallet-card" style="background:linear-gradient(135deg,${w.color}18,${w.color}08);border:1px solid ${w.color}33;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px;">
          <div>
            <div style="font-size:28px;">${walletIcons[w.type] || '💳'}</div>
            <div style="font-weight:700;font-size:16px;margin-top:8px;">${w.name}</div>
            <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;">${w.type}</div>
          </div>
          <button onclick="deleteWallet('${w.id}')" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:16px;" title="Delete">🗑️</button>
        </div>
        <div class="mono" style="font-size:26px;font-weight:700;color:${w.color};margin-bottom:14px;">${fmt(w.balance)}</div>
        <div style="display:flex;gap:14px;font-size:12px;color:var(--muted);">
          <span>↑ ${fmt(income)}</span>
          <span>↓ ${fmt(expense)}</span>
          <span>${txCount} txns</span>
        </div>
      </div>
    `;
  }).join('');
}

async function deleteWallet(walletId) {
  if (!confirm('Delete this wallet? Transactions will remain but unlinked.')) return;
  try {
    await window._deleteDoc(window._doc(window._db, 'users', window._user.uid, 'wallets', walletId));
    state.wallets = state.wallets.filter(w => w.id !== walletId);
    renderWallets();
    renderDashboard();
    showToast('Wallet deleted');
  } catch (e) {
    showToast('Error deleting wallet', 'error');
  }
}

// ======= CRYPTO =======
function openAddCrypto(type = 'holding') {
  const plan = window._userProfile?.plan || 'free';
  if (plan === 'free') { showUpgradeModal(); return; }
  document.getElementById('cryptoModalTitle').textContent = type === 'airdrop' ? '+ Add Airdrop' : '+ Add Crypto Holding';
  document.getElementById('cryptoType').value = type;
  document.getElementById('cryptoToken').value = '';
  document.getElementById('cryptoAmount').value = '';
  document.getElementById('cryptoBuyPrice').value = '';
  document.getElementById('cryptoCurrentPrice').value = '';
  document.getElementById('cryptoDate').value = today();
  openModal('addCryptoModal');
}

async function saveCrypto() {
  const token = document.getElementById('cryptoToken').value.trim();
  const amount = parseFloat(document.getElementById('cryptoAmount').value);
  const buyPrice = parseFloat(document.getElementById('cryptoBuyPrice').value) || 0;
  const currentPrice = parseFloat(document.getElementById('cryptoCurrentPrice').value) || 0;
  const type = document.getElementById('cryptoType').value;
  const date = document.getElementById('cryptoDate').value;

  if (!token || !amount) return showToast('Fill token name and amount', 'error');

  try {
    const entry = { token, amount, buyPrice, currentPrice, type, date, createdAt: window._serverTimestamp() };
    const ref = await window._addDoc(window._collection(window._db, 'users', window._user.uid, 'crypto'), entry);
    entry.id = ref.id;
    state.cryptoEntries.push(entry);
    closeModal('addCryptoModal');
    renderCrypto();
    showToast('₿ Crypto entry saved!');
  } catch (e) {
    showToast('Error saving', 'error');
  }
}

function renderCrypto() {
  const totalValue = state.cryptoEntries.reduce((a,e) => a + (e.currentPrice || 0), 0);
  const totalBuy = state.cryptoEntries.reduce((a,e) => a + (e.buyPrice || 0), 0);
  const pnl = totalValue - totalBuy;
  const airdropVal = state.cryptoEntries.filter(e => e.type === 'airdrop').reduce((a,e) => a + (e.currentPrice || 0), 0);

  document.getElementById('cryptoTotal').textContent = fmt(totalValue);
  const pnlEl = document.getElementById('cryptoPnl');
  pnlEl.textContent = (pnl >= 0 ? '+' : '') + fmt(pnl);
  pnlEl.className = `stat-value ${pnl >= 0 ? 'green' : 'red'}`;
  document.getElementById('airdropTotal').textContent = fmt(airdropVal);

  const list = document.getElementById('cryptoList');
  if (state.cryptoEntries.length === 0) {
    list.innerHTML = `<div class="empty-state"><div class="empty-icon">₿</div><p>No crypto entries yet.</p></div>`;
    return;
  }
  list.innerHTML = state.cryptoEntries.map(e => {
    const pnl = (e.currentPrice || 0) - (e.buyPrice || 0);
    return `
      <div class="crypto-row">
        <div>
          <div style="font-weight:700;font-size:15px;">${e.token}</div>
          <div style="font-size:12px;color:var(--muted);">${e.amount} tokens · ${e.type === 'airdrop' ? '🪂 Airdrop' : '📈 Holding'} · ${fmtDate(e.date)}</div>
        </div>
        <div style="text-align:right;">
          <div class="mono" style="font-weight:700;">${fmt(e.currentPrice)}</div>
          <div class="mono" style="font-size:12px;color:${pnl >= 0 ? 'var(--green)' : 'var(--red)'};">${pnl >= 0 ? '+' : ''}${fmt(pnl)}</div>
        </div>
        <button onclick="deleteCrypto('${e.id}')" style="background:none;border:none;color:var(--muted);cursor:pointer;margin-left:10px;">🗑️</button>
      </div>
    `;
  }).join('');
}

async function deleteCrypto(id) {
  if (!confirm('Delete this entry?')) return;
  await window._deleteDoc(window._doc(window._db, 'users', window._user.uid, 'crypto', id));
  state.cryptoEntries = state.cryptoEntries.filter(e => e.id !== id);
  renderCrypto();
  showToast('Deleted');
}

// ======= ANALYTICS =======
function populateMonthSelector() {
  const sel = document.getElementById('analyticsMonthSel');
  if (!sel) return;
  const months = [];
  const now = new Date();
  for (let i = 0; i < 12; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push({ value: `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`, label: monthName(d) });
  }
  sel.innerHTML = months.map(m => `<option value="${m.value}">${m.label}</option>`).join('');
}

function renderAnalytics() {
  const selVal = document.getElementById('analyticsMonthSel')?.value || '';
  const [year, month] = selVal ? selVal.split('-').map(Number) : [new Date().getFullYear(), new Date().getMonth()+1];

  const monthTx = state.transactions.filter(t => {
    const d = new Date(t.date);
    return d.getFullYear() === year && d.getMonth() + 1 === month;
  });

  // Income vs Expense chart
  const income = monthTx.filter(t => t.type === 'income').reduce((a,t) => a+t.amount, 0);
  const expense = monthTx.filter(t => t.type === 'expense').reduce((a,t) => a+t.amount, 0);

  const ieCanvas = document.getElementById('incomeExpenseChart');
  if (ieCanvas) {
    if (state.charts.ie) state.charts.ie.destroy();
    state.charts.ie = new Chart(ieCanvas, {
      type: 'doughnut',
      data: {
        labels: ['Income', 'Expenses'],
        datasets: [{ data: [income, expense], backgroundColor: ['rgba(0,255,135,0.8)','rgba(255,77,77,0.8)'], borderWidth: 0 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { labels: { color: '#888' } } }
      }
    });
  }

  // Category breakdown
  const catSpend = {};
  monthTx.filter(t => t.type === 'expense').forEach(t => {
    const cat = state.categories.find(c => c.id === t.category) || { name: t.category };
    catSpend[cat.name] = (catSpend[cat.name] || 0) + t.amount;
  });
  const catCanvas = document.getElementById('categoryChart');
  if (catCanvas) {
    if (state.charts.cat) state.charts.cat.destroy();
    const entries = Object.entries(catSpend).sort((a,b) => b[1]-a[1]).slice(0, 6);
    const colors = ['#FF6B6B','#4ECDC4','#45B7D1','#96CEB4','#FFEAA7','#DDA0DD'];
    state.charts.cat = new Chart(catCanvas, {
      type: 'pie',
      data: {
        labels: entries.map(e => e[0]),
        datasets: [{ data: entries.map(e => e[1]), backgroundColor: colors, borderWidth: 0 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { labels: { color: '#888', font: { size: 11 } } } }
      }
    });
  }

  // Daily trend
  const daysInMonth = new Date(year, month, 0).getDate();
  const dailySpend = Array(daysInMonth).fill(0);
  monthTx.filter(t => t.type === 'expense').forEach(t => {
    const day = new Date(t.date).getDate() - 1;
    if (day >= 0 && day < daysInMonth) dailySpend[day] += t.amount;
  });

  const dtCanvas = document.getElementById('dailyTrendChart');
  if (dtCanvas) {
    if (state.charts.daily) state.charts.daily.destroy();
    state.charts.daily = new Chart(dtCanvas, {
      type: 'line',
      data: {
        labels: Array.from({length: daysInMonth}, (_,i) => i+1),
        datasets: [{
          label: 'Daily Spend',
          data: dailySpend,
          borderColor: 'rgba(0,255,135,0.8)',
          backgroundColor: 'rgba(0,255,135,0.1)',
          fill: true,
          tension: 0.4,
          pointRadius: 3,
          pointBackgroundColor: '#00FF87'
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { color: '#1a1a1a' }, ticks: { color: '#666' } },
          y: { grid: { color: '#1a1a1a' }, ticks: { color: '#666', callback: v => '₹'+v } }
        }
      }
    });
  }
}

// ======= BUDGET =======
function openAddBudget() {
  populateCategorySelect('budgetCategory', 'expense');
  document.getElementById('budgetAmount').value = '';
  openModal('addBudgetModal');
}

async function saveBudget() {
  const categoryId = document.getElementById('budgetCategory').value;
  const limit = parseFloat(document.getElementById('budgetAmount').value);
  if (!categoryId || !limit || limit <= 0) return showToast('Enter valid budget', 'error');

  try {
    const existing = state.budgets.find(b => b.categoryId === categoryId);
    if (existing) {
      await window._updateDoc(window._doc(window._db, 'users', window._user.uid, 'budgets', existing.id), { limit });
      existing.limit = limit;
    } else {
      const budget = { categoryId, limit, createdAt: window._serverTimestamp() };
      const ref = await window._addDoc(window._collection(window._db, 'users', window._user.uid, 'budgets'), budget);
      budget.id = ref.id;
      state.budgets.push(budget);
    }
    closeModal('addBudgetModal');
    renderBudget();
    showToast('🎯 Budget set!');
  } catch (e) {
    showToast('Error saving budget', 'error');
  }
}

function renderBudget() {
  const list = document.getElementById('budgetList');
  if (!list) return;
  if (state.budgets.length === 0) {
    list.innerHTML = `<div class="empty-state"><div class="empty-icon">🎯</div><p>No budgets set yet.</p></div>`;
    return;
  }
  const now = new Date();
  list.innerHTML = state.budgets.map(b => {
    const cat = state.categories.find(c => c.id === b.categoryId) || { name: b.categoryId, icon: '💰' };
    const spent = state.transactions
      .filter(t => t.category === b.categoryId && t.type === 'expense' && new Date(t.date).getMonth() === now.getMonth())
      .reduce((a,t) => a+t.amount, 0);
    const pct = Math.min(Math.round((spent / b.limit) * 100), 100);
    const over = spent > b.limit;
    const warn = spent >= b.limit * 0.8;
    const barColor = over ? 'var(--red)' : warn ? 'var(--yellow)' : 'var(--green)';
    return `
      <div class="card" style="padding:20px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
          <div style="display:flex;align-items:center;gap:10px;">
            <span style="font-size:22px;">${cat.icon || '💰'}</span>
            <div>
              <div style="font-weight:700;">${cat.name}</div>
              <div style="font-size:12px;color:var(--muted);">Monthly budget</div>
            </div>
          </div>
          <div style="text-align:right;">
            <div class="mono" style="font-weight:700;color:${barColor};">${fmt(spent)} / ${fmt(b.limit)}</div>
            ${over ? '<div class="badge badge-red">EXCEEDED</div>' : warn ? '<div class="badge badge-yellow">⚠️ Warning</div>' : ''}
          </div>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" style="width:${pct}%;background:${barColor};"></div>
        </div>
        <div style="display:flex;justify-content:space-between;margin-top:8px;font-size:12px;color:var(--muted);">
          <span>${pct}% used</span>
          <span>Remaining: ${fmt(Math.max(b.limit - spent, 0))}</span>
          <button onclick="deleteBudget('${b.id}')" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:12px;">Delete</button>
        </div>
      </div>
    `;
  }).join('');
}

async function deleteBudget(id) {
  await window._deleteDoc(window._doc(window._db, 'users', window._user.uid, 'budgets', id));
  state.budgets = state.budgets.filter(b => b.id !== id);
  renderBudget();
  showToast('Budget deleted');
}

// ======= CATEGORIES =======
function openAddCategory() {
  document.getElementById('catName').value = '';
  document.getElementById('catIcon').value = '';
  openModal('addCategoryModal');
}

async function saveCategory() {
  const name = document.getElementById('catName').value.trim();
  const icon = document.getElementById('catIcon').value.trim() || '💰';
  const type = document.getElementById('catType').value;
  if (!name) return showToast('Enter category name', 'error');

  const colors = ['#FF6B6B','#4ECDC4','#45B7D1','#96CEB4','#FFEAA7','#DDA0DD','#FFD700','#9664ff'];
  const color = colors[Math.floor(Math.random() * colors.length)];

  try {
    const cat = { name, icon, type, color, custom: true };
    const id = name.toLowerCase().replace(/\s+/g,'-') + '-' + Date.now();
    await window._setDoc(window._doc(window._db, 'users', window._user.uid, 'categories', id), cat);
    cat.id = id;
    state.categories.push(cat);
    closeModal('addCategoryModal');
    renderCategories();
    showToast('🏷️ Category added!');
  } catch (e) {
    showToast('Error saving category', 'error');
  }
}

function renderCategories() {
  const expList = document.getElementById('expenseCatList');
  const incList = document.getElementById('incomeCatList');
  const expCats = state.categories.filter(c => c.type === 'expense');
  const incCats = state.categories.filter(c => c.type === 'income');

  const catItemHTML = (c) => `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border);">
      <div style="display:flex;align-items:center;gap:10px;">
        <div style="width:32px;height:32px;border-radius:8px;background:${c.color}22;display:flex;align-items:center;justify-content:center;">${c.icon || '💰'}</div>
        <span style="font-size:14px;font-weight:600;">${c.name}</span>
        ${c.custom ? '<span class="badge badge-green" style="font-size:10px;">custom</span>' : ''}
      </div>
      ${c.custom ? `<button onclick="deleteCategory('${c.id}')" style="background:none;border:none;color:var(--muted);cursor:pointer;">🗑️</button>` : ''}
    </div>
  `;

  expList.innerHTML = expCats.length ? expCats.map(catItemHTML).join('') : '<div style="color:var(--muted);font-size:13px;">No expense categories</div>';
  incList.innerHTML = incCats.length ? incCats.map(catItemHTML).join('') : '<div style="color:var(--muted);font-size:13px;">No income categories</div>';
}

async function deleteCategory(id) {
  if (!confirm('Delete this category?')) return;
  await window._deleteDoc(window._doc(window._db, 'users', window._user.uid, 'categories', id));
  state.categories = state.categories.filter(c => c.id !== id);
  renderCategories();
  showToast('Category deleted');
}

// ======= AI ASSISTANT =======
function sendChat() {
  const input = document.getElementById('chatInput');
  const msg = input.value.trim();
  if (!msg) return;
  askAI(msg);
  input.value = '';
}

function askAI(question) {
  const plan = window._userProfile?.plan || 'free';
  if (plan === 'free') { showUpgradeModal(); return; }

  appendChat(question, 'user');
  const response = getAIResponse(question.toLowerCase());
  setTimeout(() => appendChat(response, 'ai'), 600);
}

function appendChat(msg, role) {
  const msgs = document.getElementById('chatMessages');
  const div = document.createElement('div');
  div.className = `chat-bubble ${role}`;
  div.textContent = msg;
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
}

function getAIResponse(q) {
  const now = new Date();
  const todayStr = today();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const todayTx = state.transactions.filter(t => t.date === todayStr);
  const monthTx = state.transactions.filter(t => {
    const d = new Date(t.date);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  });

  const todaySpend = todayTx.filter(t => t.type === 'expense').reduce((a,t) => a+t.amount, 0);
  const monthSpend = monthTx.filter(t => t.type === 'expense').reduce((a,t) => a+t.amount, 0);
  const monthIncome = monthTx.filter(t => t.type === 'income').reduce((a,t) => a+t.amount, 0);
  const savings = monthIncome - monthSpend;
  const totalBal = state.wallets.reduce((a,w) => a+(w.balance||0), 0);

  // Category analysis
  const catSpend = {};
  monthTx.filter(t => t.type === 'expense').forEach(t => {
    const cat = state.categories.find(c => c.id === t.category) || { name: t.category };
    catSpend[cat.name] = (catSpend[cat.name] || 0) + t.amount;
  });
  const topCat = Object.entries(catSpend).sort((a,b) => b[1]-a[1])[0];

  // Route to appropriate response
  if (q.includes('today') && (q.includes('spend') || q.includes('spent'))) {
    return `📊 Today you spent ${fmt(todaySpend)} across ${todayTx.filter(t=>t.type==='expense').length} transactions.${todaySpend > 1000 ? ' You\'re spending quite a bit today! Try to stay mindful.' : ' Good spending control today! 🎉'}`;
  }
  if (q.includes('month') && (q.includes('spend') || q.includes('spent') || q.includes('expense'))) {
    return `📅 This month (${monthName()}), you've spent ${fmt(monthSpend)} across ${monthTx.filter(t=>t.type==='expense').length} expense transactions.`;
  }
  if (q.includes('income') || q.includes('earn')) {
    return `💰 Your total income this month is ${fmt(monthIncome)} from ${monthTx.filter(t=>t.type==='income').length} income entries.`;
  }
  if (q.includes('saving') || q.includes('save') || q.includes('net')) {
    if (savings < 0) return `⚠️ You're spending more than you earn this month! You're ${fmt(Math.abs(savings))} in the negative. Consider cutting expenses immediately.`;
    const savePct = monthIncome > 0 ? Math.round((savings / monthIncome) * 100) : 0;
    return `💚 Your net savings this month: ${fmt(savings)} (${savePct}% of income). ${savePct >= 20 ? 'Excellent! You\'re saving well.' : savePct >= 10 ? 'Good start! Try to save at least 20%.' : 'Aim to save at least 20% of your income.'}`;
  }
  if (q.includes('top') || q.includes('most') || q.includes('category')) {
    if (!topCat) return '📊 No expense data this month yet. Start tracking your expenses!';
    return `🏆 Your top expense category this month is "${topCat[0]}" at ${fmt(topCat[1])}. ${topCat[1] > monthSpend * 0.4 ? 'This is 40%+ of your spending — consider if you can reduce here.' : 'Looks like a reasonable distribution.'}`;
  }
  if (q.includes('balance') || q.includes('total')) {
    return `🏦 Your total balance across all wallets is ${fmt(totalBal)}.`;
  }
  if (q.includes('tip') || q.includes('advice') || q.includes('improve')) {
    const tips = [
      `💡 Track every expense, even small ones. Tiny leaks sink big ships!`,
      `📊 The 50/30/20 rule: 50% needs, 30% wants, 20% savings. You're currently saving ${monthIncome > 0 ? Math.round((savings/monthIncome)*100) : 0}%.`,
      `🎯 Set monthly budgets per category to stay on track. Use the Budget feature!`,
      `₿ Your crypto portfolio is worth ${fmt(state.cryptoEntries.reduce((a,e)=>a+(e.currentPrice||0),0))}. Diversify wisely.`,
      `💰 Automate your savings: transfer ${fmt(monthIncome * 0.2)} to savings as soon as you receive your income.`,
    ];
    return tips[Math.floor(Math.random() * tips.length)];
  }
  if (q.includes('wallet')) {
    if (state.wallets.length === 0) return '🏦 No wallets found. Add wallets to track your accounts!';
    return `🏦 You have ${state.wallets.length} wallet(s): ${state.wallets.map(w => `${w.name} (${fmt(w.balance)})`).join(', ')}.`;
  }
  if (q.includes('crypto') || q.includes('airdrop')) {
    const cv = state.cryptoEntries.reduce((a,e)=>a+(e.currentPrice||0),0);
    return `₿ Your crypto portfolio is currently worth ${fmt(cv)} across ${state.cryptoEntries.length} entries.`;
  }
  if (q.includes('hello') || q.includes('hi') || q.includes('hey')) {
    return `👋 Hey! I'm Fin, your financial AI. Ask me about your spending, income, savings, top categories, or tips to improve your finances!`;
  }
  return `🤔 I didn't quite get that. Try asking:\n• "How much did I spend this month?"\n• "What's my top expense category?"\n• "Give me saving tips"\n• "What's my total balance?"`;
}

// ======= EXPORT =======
function populateExportWalletFilter() {
  const sel = document.getElementById('exportWallet');
  if (!sel) return;
  sel.innerHTML = '<option value="all">All Wallets</option>' + state.wallets.map(w => `<option value="${w.id}">${w.name}</option>`).join('');
}

function exportData(format) {
  const from = document.getElementById('exportFrom')?.value;
  const to = document.getElementById('exportTo')?.value;
  const walletId = document.getElementById('exportWallet')?.value || 'all';

  let filtered = state.transactions;
  if (from) filtered = filtered.filter(t => t.date >= from);
  if (to) filtered = filtered.filter(t => t.date <= to);
  if (walletId !== 'all') filtered = filtered.filter(t => t.walletId === walletId);

  if (filtered.length === 0) return showToast('No transactions in selected range', 'error');

  if (format === 'csv') {
    const headers = ['Date','Type','Amount','Category','Wallet','Notes'];
    const rows = filtered.map(t => {
      const cat = state.categories.find(c => c.id === t.category)?.name || t.category;
      const wallet = state.wallets.find(w => w.id === t.walletId)?.name || t.walletId;
      return [t.date, t.type, t.amount, cat, wallet, t.notes || ''].map(v => `"${v}"`).join(',');
    });
    const csv = [headers.join(','), ...rows].join('\n');
    downloadFile(csv, `mymoney-export-${today()}.csv`, 'text/csv');
  } else {
    const data = filtered.map(t => ({
      date: t.date, type: t.type, amount: t.amount,
      category: state.categories.find(c => c.id === t.category)?.name || t.category,
      wallet: state.wallets.find(w => w.id === t.walletId)?.name || t.walletId,
      notes: t.notes || ''
    }));
    downloadFile(JSON.stringify({ exported: new Date().toISOString(), count: data.length, transactions: data }, null, 2),
      `mymoney-export-${today()}.json`, 'application/json');
  }
  showToast(`📤 Exported ${filtered.length} transactions!`);
}

function downloadFile(content, filename, type) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([content], { type }));
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

// ======= REFERRAL =======
function copyRefCode() {
  const code = document.getElementById('refCodeDisplay')?.value;
  if (!code) return;
  navigator.clipboard.writeText(code).then(() => showToast('Referral code copied!'));
}

function shareRef(platform) {
  const code = document.getElementById('refCodeDisplay')?.value || '';
  const msg = `Join MyMoney — India's smartest money tracker! Use my code ${code} to get started. https://mymoney.app`;
  if (platform === 'whatsapp') window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank');
  else if (platform === 'twitter') window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(msg)}`, '_blank');
}

// ======= SETTINGS =======
async function updateProfile() {
  const name = document.getElementById('settingsName').value.trim();
  if (!name) return showToast('Enter your name', 'error');
  try {
    await window._updateProfile(window._auth.currentUser, { displayName: name });
    await window._updateDoc(window._doc(window._db, 'users', window._user.uid), { name });
    window._userProfile.name = name;
    document.getElementById('userName').textContent = name;
    document.getElementById('userAvatar').textContent = name[0].toUpperCase();
    showToast('✅ Profile updated!');
  } catch (e) {
    showToast('Error updating profile', 'error');
  }
}

function applyPromo() {
  const code = document.getElementById('promoInput').value.trim().toUpperCase();
  const msg = document.getElementById('promoMsg');
  const promo = PROMO_CODES[code];
  if (!promo) {
    msg.style.color = 'var(--red)';
    msg.textContent = '❌ Invalid promo code';
    return;
  }
  msg.style.color = 'var(--green)';
  msg.textContent = `✅ Code applied! ${promo.discount}${promo.type === 'percent' ? '%' : ' days'} discount on ${promo.plan} plan.`;
  // Store for payment
  window._activePromo = { code, ...promo };
}

async function confirmDeleteAllData() {
  if (!confirm('⚠️ Delete ALL your data permanently? This cannot be undone.')) return;
  if (!confirm('Are you absolutely sure? Type-in YES to confirm.')) return;
  showToast('Deleting all data...', 'error');
  try {
    const uid = window._user.uid;
    const colls = ['transactions','wallets','categories','crypto','budgets'];
    for (const coll of colls) {
      const snap = await window._getDocs(window._collection(window._db, 'users', uid, coll));
      for (const d of snap.docs) await window._deleteDoc(d.ref);
    }
    state.transactions = []; state.wallets = []; state.categories = [];
    state.cryptoEntries = []; state.budgets = [];
    showToast('All data deleted');
    renderDashboard();
  } catch (e) {
    showToast('Error deleting data', 'error');
  }
}

// ======= UPGRADE / PAYMENT =======
function showUpgradeModal() {
  openModal('upgradeModal');
}

function initPayment(planId, baseAmount) {
  // Apply promo code discount if any
  let amount = baseAmount;
  if (window._activePromo && window._activePromo.type === 'percent') {
    amount = Math.round(amount * (1 - window._activePromo.discount / 100));
  }

  const options = {
    key: RAZORPAY_KEY,
    amount: amount * 100, // paise
    currency: 'INR',
    name: 'MyMoney by AKASH B',
    description: planId === 'pro_monthly' ? 'Pro Monthly Plan' : 'Lifetime Access',
    image: '', // Add your logo URL
    handler: async function(response) {
      // Payment success
      await handlePaymentSuccess(planId, response.razorpay_payment_id);
    },
    prefill: {
      name: window._userProfile?.name || '',
      email: window._user?.email || '',
    },
    theme: { color: '#00FF87' },
    modal: { backdropclose: false }
  };

  // Load Razorpay script if not loaded
  if (typeof Razorpay === 'undefined') {
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => new Razorpay(options).open();
    document.head.appendChild(script);
  } else {
    new Razorpay(options).open();
  }
}

async function handlePaymentSuccess(planId, paymentId) {
  try {
    const plan = planId === 'lifetime' ? 'lifetime' : 'pro';
    const uid = window._user.uid;

    // Update user plan
    await window._updateDoc(window._doc(window._db, 'users', uid), {
      plan,
      updatedAt: window._serverTimestamp(),
    });

    // Store subscription record
    await window._addDoc(window._collection(window._db, 'users', uid, 'subscriptions'), {
      plan, planId, paymentId,
      amount: planId === 'lifetime' ? 999 : 99,
      createdAt: window._serverTimestamp(),
      promoCode: window._activePromo?.code || null,
    });

    window._userProfile.plan = plan;

    // Update UI
    const badge = document.getElementById('planBadge');
    badge.textContent = plan === 'lifetime' ? '⭐ LIFETIME' : '⚡ PRO';
    badge.className = 'badge badge-yellow';
    document.getElementById('upgradeBanner').style.display = 'none';
    document.getElementById('upgradeBtn').style.display = plan === 'lifetime' ? 'none' : '';
    document.getElementById('assistantLock').style.display = 'none';
    document.getElementById('subscriptionInfo').textContent = plan === 'lifetime' ? '⭐ Lifetime Plan — Unlimited forever' : '⚡ Pro Plan — Active';

    closeModal('upgradeModal');
    showToast(`🎉 Welcome to ${plan === 'lifetime' ? 'Lifetime' : 'Pro'} plan!`);
  } catch (e) {
    showToast('Payment recorded but profile update failed. Contact support.', 'error');
  }
}

// ======= LOGOUT =======
async function handleLogout() {
  if (!confirm('Logout of MyMoney?')) return;
  await window._signOut(window._auth);
  localStorage.clear();
  window.location.href = 'index.html';
}

// ======= INIT AFTER LOAD =======
document.addEventListener('DOMContentLoaded', () => {
  // Pre-populate month selector
  try { populateMonthSelector(); } catch (_) {}

  // Lazy-populate wallet filter the first time the user opens transactions page
  const navBtn = document.getElementById('nav-transactions');
  if (navBtn) {
    navBtn.addEventListener('click', () => { try { populateTxWalletFilter(); } catch (_) {} }, { once: true });
  }

  // Close modals on overlay click
  document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.classList.remove('open');
    });
  });
});

// ======= PWA SERVICE WORKER =======
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  });
}