// firebase.js — Firebase initialization + auth bridge
// Works for BOTH index.html (landing/auth) and dashboard.html (app)
// v1.0.1 | by AKASH B

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js';
import {
  getAuth,
  onAuthStateChanged,
  signOut,
  updateProfile,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js';
import {
  getFirestore,
  collection,
  doc,
  addDoc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  Timestamp
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js';

/* =====================================================================
   FIREBASE CONFIG — REPLACE THE PLACEHOLDERS BELOW WITH YOUR OWN KEYS
   Get them from: Firebase Console → Project Settings → General → Your apps
   ===================================================================== */
const firebaseConfig = {
  apiKey:            "YOUR_API_KEY",
  authDomain:        "YOUR_PROJECT.firebaseapp.com",
  projectId:         "YOUR_PROJECT_ID",
  storageBucket:     "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId:             "YOUR_APP_ID"
};
/* ===================================================================== */

const app  = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db   = getFirestore(app);

/* ---------- Detect page ---------- */
// A page is treated as "dashboard" if the document body carries
// data-page="dashboard" OR if the URL ends in dashboard.html
const isDashboardPage = () => {
  if (document.body && document.body.dataset.page === 'dashboard') return true;
  return /dashboard\.html?$/i.test(window.location.pathname);
};

/* ---------- Expose globals used by app.js & index.html ---------- */
Object.assign(window, {
  _auth: auth,
  _db:   db,
  _doc: doc, _collection: collection,
  _addDoc: addDoc, _setDoc: setDoc, _getDoc: getDoc, _getDocs: getDocs,
  _updateDoc: updateDoc, _deleteDoc: deleteDoc,
  _query: query, _where: where, _orderBy: orderBy, _limit: limit,
  _serverTimestamp: serverTimestamp, _Timestamp: Timestamp,
  _signOut: signOut, _updateProfile: updateProfile,
  _createUserWithEmailAndPassword: createUserWithEmailAndPassword,
  _signInWithEmailAndPassword:     signInWithEmailAndPassword,
  _sendPasswordResetEmail:         sendPasswordResetEmail,
});

/* ---------- Auth-bridge helpers used by index.html ---------- */
// Sign-up → creates Firestore user profile and redirects to dashboard.
window.mmSignup = async function (name, email, password) {
  const cred = await createUserWithEmailAndPassword(auth, email, password);
  if (name) {
    try { await updateProfile(cred.user, { displayName: name }); } catch (_) {}
  }
  const referralCode = 'MM' + cred.user.uid.slice(0, 6).toUpperCase();
  try {
    await setDoc(doc(db, 'users', cred.user.uid), {
      name: name || 'User',
      email,
      plan: 'free',
      referralCode,
      createdAt: serverTimestamp(),
    });
  } catch (e) { console.warn('profile create failed', e); }
  window.location.href = 'dashboard.html';
  return cred.user;
};

// Sign-in → redirects to dashboard on success.
window.mmLogin = async function (email, password) {
  const cred = await signInWithEmailAndPassword(auth, email, password);
  window.location.href = 'dashboard.html';
  return cred.user;
};

// Password reset helper (optional use).
window.mmResetPassword = (email) => sendPasswordResetEmail(auth, email);

/* ---------- Auth state watcher (routing + app.js bootstrap) ---------- */
onAuthStateChanged(auth, async (user) => {
  if (isDashboardPage()) {
    // Dashboard: bounce to landing if not authenticated.
    if (!user) { window.location.replace('index.html'); return; }

    // Expose user + load profile for app.js
    window._user = user;

    try {
      const userRef = doc(db, 'users', user.uid);
      const snap = await getDoc(userRef);
      if (snap.exists()) {
        window._userProfile = snap.data();
      } else {
        window._userProfile = {
          name:  user.displayName || 'User',
          email: user.email,
          plan:  'free',
          referralCode: 'MM' + user.uid.slice(0, 6).toUpperCase(),
        };
        try { await setDoc(userRef, { ...window._userProfile, createdAt: serverTimestamp() }); } catch (_) {}
      }
    } catch (e) {
      console.warn('Profile fetch error:', e);
      window._userProfile = { name: user.displayName || 'User', email: user.email, plan: 'free' };
    }

    if (typeof window.onFirebaseReady === 'function') window.onFirebaseReady(user);
  } else {
    // Landing page: if already signed in, skip straight into the app.
    if (user) window.location.replace('dashboard.html');
  }
});

/* =====================================================================
   FIRESTORE SECURITY RULES (paste into Firebase Console → Firestore → Rules)
   ---------------------------------------------------------------------
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /users/{userId} {
         allow read, write: if request.auth != null && request.auth.uid == userId;
         match /{sub=**} {
           allow read, write: if request.auth != null && request.auth.uid == userId;
         }
       }
     }
   }
   ===================================================================== */
